#!/bin/bash
export HOME=/root
export TERM=xterm
NC='\e[0m'
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
ipsaya=$(curl -sS ipv4.icanhazip.com)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/arivpnstores/v7/main/izin"
checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[0;34m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          ANDA HARUS MENDAFTAR DAHULU UNTUK MENJADI SELLER         \033[0m"
    echo -e "\033[0;34m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}DAFTAR DULU DEK !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/kytxz"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/6287769315399"
    echo -e "\033[0;34m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc
Repo1="https://raw.githubusercontent.com/arivpnstores/v7/main/"
export MYIP=$( curl -sS ipv4.icanhazip.com/ )
SELLER=$(curl -sS ${Repo1}izin | grep $MYIP | awk '{print $2}')
Exp100=$(curl -sS ${Repo1}izin | grep $MYIP | awk '{print $3}')
data_ip="https://raw.githubusercontent.com/arivpnstores/v7/main/izin"
d2=$(date -d "$date_list" +"+%s")
d1=$(date -d "$Exp" +"+%s")
dayleft=$(( ($d1 - $d2) / 86400 ))
####
TOKEN="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"
REPO="https://github.com/Mrz051/vip2.git"
EMAIL="fa4573620@gmail.com"
USER="Mrz051"
today=$(date -d "0 days" +"%Y-%m-%d")
#####

# Ambil parameter dari perintah addip
ip="$1"
name="$2"
exp="$3"

git clone ${REPO} /root/ipvps/
CLIENT_EXISTS=$(grep -w $ip /root/ipvps/izin | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
echo "IP Already Exist !"
rm -rf /root/ipvps
exit 0
fi

exp2=`date -d "${exp} days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip}" >> /root/ipvps/izin

cd /root/ipvps
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m ariregist &> /dev/null
git branch -M master &> /dev/null
git remote add origin https://github.com/Mrz051/vip2.git
git push -f https://${TOKEN}@github.com/Mrz051/vip2.git &> /dev/null
rm -rf /root/ipvps

echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "🍀VPS SUCCESSFULLY REGISTER🍀"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "🌹NAME AUTHOR : $name"
echo -e "🏵️SCRIPT TIME : $exp2"
echo -e "🌺IP SERVER   : $ip"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "Link Script:

apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/arivpnstores/v7/main/premi.sh && chmod +x premi.sh && ./premi.sh"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
